from turtle import Screen, Turtle
import time
from snake import Snake
snake_positions = [(0, 0), (-10, 0), (-20, 0)]
forward_distance = 50

game_screen = Screen()
game_screen.setup(width=600, height=600)
game_screen.bgcolor("Black")
game_screen.title("Vila's Snake Game")
game_screen.tracer(0)

segment_list =[]
for positions in snake_positions:
    snake_seg = Turtle(shape='square')
    snake_seg.color("white")
    snake_seg.penup()
    snake_seg.goto(positions)
    segment_list.append(snake_seg)

game_on = True
while game_on:
    game_screen.update()
    time.sleep(1)
    for seg_num in range(len(segment_list) - 1, 0, -1):
        new_x = segment_list[seg_num - 1].xcor()
        new_y = segment_list[seg_num - 1].ycor()
        segment_list[seg_num].goto(new_x, new_y)

    segment_list[0].forward(forward_distance)


game_screen.exitonclick()
