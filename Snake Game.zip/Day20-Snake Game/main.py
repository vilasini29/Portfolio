import time
from turtle import Screen

from scoreboard import *

from snake import Snake

game_screen = Screen()
game_screen.setup(width=600, height=600)
game_screen.bgcolor("Black")
game_screen.title("Vila's Snake Game")
game_screen.tracer(0)

snake = Snake()
food = Food()
score = Scoreboard()

game_screen.listen()
game_screen.onkey(key="Up", fun=snake.up)
game_screen.onkey(key="Down", fun=snake.down)
game_screen.onkey(key="Left", fun=snake.left)
game_screen.onkey(key="Right", fun=snake.right)

game_on = True
while game_on:
    game_screen.update()
    time.sleep(0.1)
    snake.move_snake()

    # collision with food
    if snake.head.distance(food) < 15:
        food.refresh()
        score.track_score()
        snake.extend_snake()

    # detect collision with wall
    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        score.reset_scoreboard()
        score.update_score()
        snake.reset_snake()

    # detect collision with snake tail
    for segment in snake.segment_list[1:]:
        if snake.head.distance(segment) < 10:
            score.reset_scoreboard()
            score.update_score()
            snake.reset_snake()

game_over = Turtle()
game_over.color("white")
game_over.hideturtle()
game_over.goto(0, 0)
game_over.write("Game Over!", align="center", font=("Arial", 12, "bold"))

game_screen.exitonclick()
