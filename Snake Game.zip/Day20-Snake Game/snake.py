from turtle import Turtle
snake_positions = [(0, 0), (-20, 0), (-40, 0)]
forward_distance = 20

class Snake:
    def __init__(self):
        self.segment_list = []
        self.create_snake()
        self.head = self.segment_list[0]

    def create_snake(self):
        for positions in snake_positions:
            snake_seg = Turtle(shape='square')
            snake_seg.color("white")
            snake_seg.penup()
            snake_seg.goto(positions)
            snake_seg
            self.segment_list.append(snake_seg)

    def move_snake(self):
        for seg_num in range(len(self.segment_list) - 1, 0, -1):
            new_x = self.segment_list[seg_num - 1].xcor()
            new_y = self.segment_list[seg_num - 1].ycor()
            self.segment_list[seg_num].goto(new_x, new_y)
        self.segment_list[0].forward(forward_distance)

    def up(self):
        self.segment_list[0].setheading(90)
        self.move_snake()
    def down(self):
        self.segment_list[0].setheading(270)
        self.move_snake()
    def left(self):
        self.segment_list[0].setheading(180)
        self.move_snake()
    def right(self):
        self.segment_list[0].setheading(0)
        self.move_snake()

    def add_segment(self,position):
        new_seg = Turtle(shape='square')
        new_seg.color("white")
        new_seg.penup()
        new_seg.goto(position)
        self.segment_list.append(new_seg)

    def extend_snake(self):
        self.add_segment(self.segment_list[-1].position())

    def reset_snake(self):
        for seg in self.segment_list:
            seg.goto(1000,1000)
        self.segment_list.clear()
        self.create_snake()
        self.head = self.segment_list[0]